/**
 * Ultra Vehicle Card Version
 * v2.6.2
 * 
 * This file is auto-generated from src/version.ts
 * DO NOT MODIFY DIRECTLY
 */

let version = "undefined";

function setVersion(value) {
  version = value;
}

// Set default version (will be overridden by card)
setVersion('2.6.2');

export { version, setVersion };
/**
 * Ultra Vehicle Card Version
 * v2.8.1
 * 
 * This file is auto-generated from src/version.ts
 * DO NOT MODIFY DIRECTLY
 */

let version = "undefined";

function setVersion(value) {
  version = value;
}

// Set default version (will be overridden by card)
setVersion('2.8.1');

export { version, setVersion };